#define VOXNAME cmu_us_rms
#define REGISTER_VOX register_cmu_us_rms
#define UNREGISTER_VOX unregister_cmu_us_rms
#define VOXHUMAN "rms"
#define VOXGENDER "unknown"
#define VOXVERSION 1.0
